<a href="{{ route('Parking::users.accept', $id) }}">Si</a>
<a href="{{ route('Parking::users.deny', $id) }}">No</a>