<footer class="main-footer bg-ligth">
    <strong>Copyright &copy; 2023 <a href="#" style="text-decoration: none"></a>.</strong>
    All Rights Reserved
    <div class="float-right d-none d-sm-inline-block">
        <b>Version Alpha</b> 1.0
    </div>
</footer>