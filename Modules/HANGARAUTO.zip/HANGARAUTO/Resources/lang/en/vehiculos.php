<?php

return [
    // Indicador De La Vista
    'Vehicles' => 'Vehicles',
    'Vehicle' => 'Vehicle',
    'VehicleType' => 'VehicleType',
    'Add New Vehicle' => 'Add New Vehicle',
    'Reference' => 'Reference',
    'Statu' => 'Statu',
    'Plate' => 'Plate',
    'Fuel Level' => 'Fuel Level',
    'Responsability' => 'Responsability',
    'Review Date' => 'Review Date',
    'Expiration Date' => 'Expiration Date',
    'Add New Tecnomecanica_Report' => 'Add New Tecnomecanic Report',
    'Add New SOAT Report' => 'Add New SOAT Report',
    'Date' => 'Date',
    'Fuel Type' => 'Fuel Type',
    'Amount' => 'Amount',
    'Price' => 'Price',
    'Mileage' => 'Mileage',
    'Oil Consume' => 'Oil Consume',
    'Add New Consumption' => 'Add New Consumption',
    'Measurement Unit' => 'Measurement Unit',
    'Reports' => 'Reports',
    'Search Vehicle' => 'Search Vehicle',
];