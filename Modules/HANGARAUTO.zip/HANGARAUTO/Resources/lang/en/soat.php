<?php

return [
    // Indicador De La Vista Y Sidebar
    'Soat' => 'Soat',
    // Titulo 1
    'Title1' => 'SOAT Status Records and Date of Change',
];