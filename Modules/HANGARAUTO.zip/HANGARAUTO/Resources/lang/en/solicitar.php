<?php

return [
    // Indicador Sidebar Solicitar
    'Request_Vehicle' => 'Request Vehicle',
    // Indicador Pagina Solicitar
    'Request_Vehicle' => 'Request Vehicle',

    // Boton Dentro De La Card De Resultados
    'Btn_Save' => 'Save',
    //Boton dentro de la card de resultados editar
    'Btn_Update'  => 'Update',

    // Nombres De La Tabla Del Crud De Registros Guardados
    'Tilte_Card_Records_Saver' => 'Tilte_Card_Records_Saver',

    'Title_Header_Table_Column_Name'                  =>  'Name',
    'Title_Header_Table_Column_Travel_date'           =>  'Travel Date',
    'Title_Header_Table_Column_Return_Date'           =>  'Return Date',
    'Title_Header_Table_Column_Department'            =>  'Department',
    'Title_Header_Table_Column_City'                  =>  'City',
    'Title_Header_Table_Column_numstudents'           =>  'Number Students',
    'Title_Header_Table_Column_reason_for_trip'       =>  'Reason For Trip',
    'Title_Header_Table_Column_reason_for_status'     =>  'Status',
    'Title_Header_Table_Column_Action'                =>  'Actions',

    // Botones
    'btn_Assign_and_Confirm' => 'Assign and Confirm',
    'btn_deny' => 'Deny',
    'btn_Approved' => 'Approved',
    'btn_Show_Details' => 'Show Details',
];