<?php

return [
    // Indicador de la vista 
    'developers' => 'Developers',

    //Titulo de la vista de desarrolladores
    'TitleCardDevelopers' => 'DEVELOPERS AND TOOLS',

    //Titulo de la card de desarrolladores
    'TitleApprentice' => 'Apprentice',

    //Titulo del tecnologo
    'NameTechnologist' => 'Tgo. Software analysis and development'
];