<?php

return [
    // Indicador De La Vista Y Sidebar
    'fuelcomsuption' => 'Fuel Comsuption'
]; 