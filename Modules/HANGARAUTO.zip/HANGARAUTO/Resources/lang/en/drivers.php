<?php

return [
    // Indicador De La Vista Y Sidebar
    'Drivers' => 'Drivers',
    'Vehicle_Report' => 'Vehicle Report',
    'Assigned_Routes' => 'Assigned Routes',
    'Add Driver' => 'Add Driver',
    'Add New Driver' => 'Add new driver',
    'Name' => 'Name',
    'Document' => 'Document',
    'Telephone' => 'Telephone',
    'Actions' => 'Actions',
    'Search' => 'Search',
    'Cancel' => 'Cancel',
    'Save' => 'Save',
    'Document Not Found' => 'Document Not Found',
];