<?php

return [
    //Indicador del Manual
    'Report_Indicator' => 'Manual',
    //Titulo Card de la vista Manual
    'Title_Card_Manual' => 'User Manual',

    //subtitulo card Manual
    'Subtitle_Card_Manual' => 'Welcome To The User Manual! Here You Will Find Detailed Information On How To Use Our Application.',
];