<?php

return [
    // Indicador De Sidebar Y Vista
    'Tecnomechanic' => 'Tecnomechanic',
    // Titulo 1
    'Title1' => 'Status Records and Update Date of the Tecnomecanica',
    // Indicador Sidebar Mantenimientos
    'Maintainances' => 'Maintainances',
];