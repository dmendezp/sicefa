<?php

return [
    // Indicador De Sidebar Y Vista
    'Tecnomechanic' => 'Tecnomecanica',
    // Titulo 1
    'Title1' => 'Registros De Estado Y Fecha De Actualización De La Tecnomecanica',
    // Indicador Sidebar Mantenimientos
    'Maintainances' => 'Mantenimiento',
];