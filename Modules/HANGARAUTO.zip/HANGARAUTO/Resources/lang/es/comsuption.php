<?php

return [
    // Indicador De La Vista Y Sidebar
    'fuelcomsuption' => 'Consumo De Gasolina'
];