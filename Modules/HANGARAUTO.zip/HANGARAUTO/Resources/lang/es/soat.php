<?php

return [
    // Indicador De La Vista Y Sidebar
    'Soat' => 'Soat',
    'Title1' => 'Registros De Estado Y Fecha De Cambio Del SOAT',
];