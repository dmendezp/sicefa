<?php

return [
    // Indicador de la vista 
    'developers' => 'Desarrolladores',
    //Titulo de la vista de desarrolladores
    'TitleCardDevelopers' => 'DESARROLLADORES Y HERRAMIENTAS',

    //Titulo de la card de desarrolladores
    'TitleApprentice' => 'Aprendiz',

    //Titulo del tecnologo
    'NameTechnologist' => 'Tgo. Analisis y desarollo de software',
];