<?php

return [
    // Indicador De La Vista
    'Vehicles' => 'Vehiculos',
    'Vehicle' => 'Vehiculo',
    'VehicleType' => 'Tipo De Vehiculo',
    'Add New Vehicle' => 'Añadir Nuevo Vehiculo',
    'Reference' => 'Referencia',
    'Statu' => 'Estado',
    'Plate' => 'Placa',
    'Fuel Level' => 'Nivel De Gasolina',
    'Responsability' => 'Responsable',
    'Review Date' => 'Fecha Revision',
    'Expiration Date' => 'Fecha Vencimiento',
    'Add New Tecnomecanica_Report' => 'Añadir Nuevo Reporte De Tecnomecanica',
    'Add New SOAT Report' => 'Añadir Nuevo Reporte De SOAT',
    'Date' => 'Fecha',
    'Fuel Type' => 'Tipo Combustible',
    'Amount' => 'Cantidad',
    'Price' => 'Precio',
    'Mileage' => 'Kilometraje',
    'Oil Consume' => 'Consumo de Gasolina',
    'Add New Consumptione' => 'Añadir Nuevo Consumo',
    'Measurement Unit' => 'Unidad de Medida',
    'Reports' => 'Reportes',
    'Search Vehicle' => 'Consultar Vehiculo',

];