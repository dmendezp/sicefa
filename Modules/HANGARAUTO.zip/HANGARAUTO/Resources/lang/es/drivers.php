<?php

return [
    // Indicador De La Vista Y Sidebar
    'Drivers' => 'Conductores',
    'Vehicle_Report' => 'Reporte Vehiculo',
    'Assigned_Routes' => 'Rutas Asignadas',
    'Add Driver' => 'Agregar Conductor',
    'Add New Driver' => 'Agregar Nuevo Conductor',
    'Name' => 'Nombre',
    'Document' => 'Documento',
    'Telephone' => 'Telefono',
    'Actions' => 'Acciones',
    'Search' => 'Buscar',
    'Cancel' => 'Cancelar',
    'Save' => 'Guardar',
    'Document Not Found' => 'Documento no encontrado',
];