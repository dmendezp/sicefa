<?php

return [
    // Indicador Sidebar Vista Solicitar
    'Request_Vehicle' => 'Solicitar Vehiculo',
    // Indicador Pagina Solicitar
    'Request_Vehicle' => 'Solicitar Vehiculo',

    // Boton Dentro De La Card De Resultados
    'Btn_Save' => 'Guardar',

    // Nombres De La Tabla Del Crud De Registros Guardados
    'Tilte_Card_Records_Saver' => 'Registro de vehiculos solicitados',

    'Title_Header_Table_Column_Name'                  =>  'Nombre',
    'Title_Header_Table_Column_Travel_date'           => 'Fecha Del Viaje',
    'Title_Header_Table_Column_Return_Date'           =>  'Fecha Del Regreso',
    'Title_Header_Table_Column_Department'            =>  'Departamento',
    'Title_Header_Table_Column_City'                  =>  'Municipio',
    'Title_Header_Table_Column_numstudents'           =>  'N° Personas',
    'Title_Header_Table_Column_reason_for_trip'       =>  'Motivo Del Viaje',
    'Title_Header_Table_Column_reason_for_status'     =>  'Estado',
    'Title_Header_Table_Column_Action'                =>  'Acciones',

    // Botones
    'btn_Assign_and_Confirm' => 'Asignar y Confirmar',
    'btn_deny' => 'Denegar',
    'btn_Approved' => 'Aprobado',
    'btn_Show_Details' => 'Mostrar Observaciones',
];