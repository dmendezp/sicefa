<?php

return [
    //Indicador Del Manual
    'Report_Indicator' => 'Manual',
    //Titulo Card De La Vista Manual
    'Title_Card_Manual' => 'Manual de Usuario',

    //subtitulo Card Manual
    'Subtitle_Card_Manual' => '¡Bienvenido Al Manual De Usuario! Aquí Encontrarás Información Detallada Sobre Como Utilizar Nuestra Aplicación.',
];